from pathlib import Path
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import plotly.express as px
root=Path(__file__).resolve().parent
df=pd.read_csv(root/'data'/'ott_catalog_practice.csv')
(root/'outputs').mkdir(exist_ok=True)
print('Dataset shape:',df.shape)
print('Missing values:\n',df.isna().sum())
sns.countplot(data=df,y='listed_in',order=df['listed_in'].value_counts().index)
plt.title('Titles by Genre'); plt.tight_layout(); plt.savefig(root/'outputs'/'genre_popularity.png',dpi=150); plt.close()
yt=df.groupby(['release_year','type']).size().reset_index(name='title_count')
px.line(yt,x='release_year',y='title_count',color='type',markers=True,title='Release Trends').write_html(root/'outputs'/'release_trends.html')
print('Charts saved in outputs/. Run notebook for all seven visualizations.')
