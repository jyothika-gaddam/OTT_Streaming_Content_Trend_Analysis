-- Import data/ott_catalog_practice.csv as ott_catalog before running.
SELECT platform, type, COUNT(*) AS title_count FROM ott_catalog GROUP BY platform, type ORDER BY platform, title_count DESC;
SELECT listed_in AS genre, COUNT(*) AS title_count FROM ott_catalog GROUP BY listed_in ORDER BY title_count DESC;
SELECT release_year, type, COUNT(*) AS title_count FROM ott_catalog GROUP BY release_year, type ORDER BY release_year, type;
SELECT country, ROUND(AVG(duration_minutes),1) AS avg_movie_minutes, COUNT(*) AS movie_count FROM ott_catalog WHERE type='Movie' AND duration_minutes IS NOT NULL GROUP BY country HAVING COUNT(*)>=2 ORDER BY avg_movie_minutes DESC;
SELECT rating, COUNT(*) AS title_count FROM ott_catalog GROUP BY rating ORDER BY title_count DESC;
SELECT country, COUNT(*) AS title_count, COUNT(DISTINCT listed_in) AS genre_count FROM ott_catalog GROUP BY country ORDER BY title_count DESC, genre_count DESC;
WITH gp AS (SELECT platform, listed_in AS genre, COUNT(*) AS title_count FROM ott_catalog GROUP BY platform, listed_in), ranked AS (SELECT *, ROW_NUMBER() OVER(PARTITION BY platform ORDER BY title_count DESC) rn FROM gp) SELECT platform, genre, title_count FROM ranked WHERE rn<=3 ORDER BY platform, rn;
