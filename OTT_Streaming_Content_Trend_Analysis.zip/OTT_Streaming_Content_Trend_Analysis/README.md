# OTT Streaming Content Trend Analysis

## Objective
Explore genre popularity, content ratings, release trends, regional content mix, movie duration, and platform mix.

## Tools
Python (Pandas, Seaborn, Plotly, Matplotlib), SQL, and Excel.

## Dataset note
The screenshot suggests public Netflix/Amazon Prime title datasets from Kaggle. No original source CSV was attached, so this package includes a **synthetic practice dataset** with common OTT catalog fields; it is not an official Netflix, Prime Video, or Hotstar export. Replace it with a verified public dataset before presenting provider-specific findings as factual.

## Deliverables
- `data/ott_catalog_practice.csv` — 240 practice records.
- `notebooks/OTT_Content_Trend_EDA.ipynb` — EDA notebook with 7 visualizations.
- `sql/ott_analysis_queries.sql` — SQL aggregation, trend, rating, regional, and window-function queries.
- `outputs/OTT_Content_Analysis.xlsx` — Catalog and summary sheets.
- `outputs/content_strategy_memo.md` — three actionable hypotheses and follow-up metrics.
- `run_analysis.py` — runnable chart-generation script.
- `requirements.txt` — dependencies.

## Run
1. Install Python 3.10+.
2. Run `pip install -r requirements.txt`.
3. Open `notebooks/OTT_Content_Trend_EDA.ipynb` in Jupyter and run all cells.
4. Or run `python run_analysis.py`.
5. Import the CSV into your SQL tool as `ott_catalog` and execute the SQL file.
6. Review the Excel workbook tabs: Catalog, Genre Summary, Platform Summary, Release Trends.

## Questions explored
Which genres have the most titles? How does content type vary? What release-year patterns appear? Which ratings and countries are most represented? How does movie duration vary by genre? How does platform content mix differ?

## Caution
Since the dataset is synthetic, findings are for practicing EDA and storytelling only. Validate with a real public catalog and engagement metrics before making business decisions.
