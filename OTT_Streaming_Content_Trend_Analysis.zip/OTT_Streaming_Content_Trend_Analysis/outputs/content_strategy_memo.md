# Content Strategy Memo: OTT Catalog Trends
**To:** Content Acquisition & Growth Team  
**Subject:** Initial catalog patterns and follow-up actions

## Executive summary
This project demonstrates EDA across genre popularity, ratings, release trends, regional representation, duration, and platform mix.

**Data limitation:** The included 240-row dataset is synthetic practice data modeled on common OTT catalog fields. It is not a downloaded Netflix, Prime Video, or Hotstar catalog, so its rankings are illustrative and must not be presented as real provider findings.

## Three actionable hypotheses
1. **Genre acquisition:** Largest practice-sample categories: Crime (31), Thriller (28), Animation (28). Validate genre title counts against viewing hours, completion rate, and licensing cost before greenlighting similar content.
2. **Refresh older titles:** Compare actual catalog release years with watch hours and retention. Test refreshed artwork, curated collections, or recommendations for older titles.
3. **Regional discovery:** Compare verified country-level genre and rating mix. Use evidence to prioritize subtitles, dubbing, and local promotion rather than assuming markets behave alike.

## Metrics to add
- Watch hours and unique viewers by title
- Completion rate and episode drop-off
- Search impressions-to-play conversion
- Subscriber retention associated with content
- Licensing cost, rights window, and contribution margin

## Recommendation
Treat this package as an analysis template. Re-run against a verified public Netflix/Amazon Prime titles dataset and engagement metrics before making business claims.
